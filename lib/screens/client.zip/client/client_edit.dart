import 'package:flutter/material.dart';
import 'package:quotation_flutter/services/client/client_service.dart';
import 'package:quotation_flutter/utils/appUtils/app_utils.dart';
import 'package:quotation_flutter/widgets/customAppbar/custom_appbar.dart';
import 'package:intl/intl.dart';

class ClientEdit extends StatefulWidget {
  const ClientEdit({
    super.key,
    required this.clientRecord,
    required this.authToken,
    required this.companyId,
    required this.languageId,
    required this.loginResponse,
  });

  final dynamic clientRecord;
  final String? authToken;
  final dynamic loginResponse;
  final dynamic companyId;
  final dynamic languageId;
  @override
  State<ClientEdit> createState() => _ClientEditState();
}

class _ClientEditState extends State<ClientEdit> {
  List<dynamic> clienttypes = [];
  List<dynamic> genderCode = [];
  List<dynamic> salutationType = [];
  List<dynamic> language = [];
  List<dynamic> clientStatus = [];
  // List<dynamic> addressLists = [];
  TextEditingController searchString = TextEditingController();
  String searchCriteria = "client_sur_name";
  String dropdownValue = "I";
  TextEditingController pageNo = TextEditingController();
  int pageSize = 0;

  Map<String, dynamic> initialvalues = {
    "ClientType": "",
    "ClientShortName": "",
    "ClientLongName": "",
    "ClientSurName": "",
    "Gender": "",
    "Salutation": "",
    "Language": "",
    "ClientDob": "",
    "ClientDod": "",
    "ClientEmail": "",
    "ClientMobile": "",
    "ClientStatus": "",
  };

  void resetInitialValues() {
    initialvalues.update("ClientType", (value) => "");
    initialvalues.update("ClientShortName", (value) => "");
    initialvalues.update("ClientLongName", (value) => "");
    initialvalues.update("ClientSurName", (value) => "");
    initialvalues.update("Gender", (value) => "");
    initialvalues.update("Salutation", (value) => "");
    initialvalues.update("Language", (value) => "");
    initialvalues.update("ClientDob", (value) => "");
    initialvalues.update("ClientDod", (value) => "");
    initialvalues.update("ClientEmail", (value) => "");
    initialvalues.update("ClientMobile", (value) => "");
    initialvalues.update("ClientStatus", (value) => "");
  }

  TextEditingController clientDob = TextEditingController();
  TextEditingController clientDod = TextEditingController();

  Future<dynamic> getGender() async {
    final response = await ClientService.getGender(
        widget.authToken, widget.companyId, widget.languageId, "P0022");
    setState(() {
      genderCode = response["data"];
    });
  }

  @override
  Widget build(BuildContext context) {
    String selectedValue = widget.clientRecord["ClientType"];

    void handleRadioValueChanged(String? value) {
      setState(() {
        selectedValue = value!;
        widget.clientRecord.update("ClientType", (val) => selectedValue);
      });
    }

    return Scaffold(
      appBar: CustomAppBar(title: "Client Edit", isBack: false),
      body: Form(
        child: ListView(
          children: [
            Center(
              child: Text(
                "Client",
                style: TextStyle(
                  color: Theme.of(context).colorScheme.primary,
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              children: [
                Flexible(
                  child: RadioListTile<String>(
                    title: const Text('Individual'),
                    value: 'I',
                    groupValue: selectedValue,
                    onChanged: handleRadioValueChanged,
                  ),
                ),
                Flexible(
                  child: RadioListTile<String>(
                    title: const Text('Corporate'),
                    value: 'C',
                    groupValue: selectedValue,
                    onChanged: handleRadioValueChanged,
                  ),
                ),
              ],
            ),
            Row(
              children: [
                Flexible(
                  child: TextFormField(
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    initialValue: widget.clientRecord["ClientShortName"],
                    onChanged: (value) {
                      widget.clientRecord
                          .update("ClientShortName", (val) => value);
                    },
                    decoration: InputDecoration(
                        border: const OutlineInputBorder(),
                        label: Text(
                          "Client Short Name",
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        )),
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                Flexible(
                  child: TextFormField(
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    initialValue: widget.clientRecord["ClientLongName"],
                    onChanged: (value) {
                      widget.clientRecord
                          .update("ClientLongName", (val) => value);
                    },
                    decoration: InputDecoration(
                        border: const OutlineInputBorder(),
                        label: Text(
                          "Client Long Name",
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        )),
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              children: [
                Flexible(
                  child: TextFormField(
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    initialValue: widget.clientRecord["ClientSurName"],
                    onChanged: (value) {
                      widget.clientRecord
                          .update("ClientSurName", (val) => value);
                    },
                    decoration: InputDecoration(
                        border: const OutlineInputBorder(),
                        label: Text(
                          "Client Sur Name",
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        )),
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                StatefulBuilder(
                  builder: (context, setDropdownState) => Flexible(
                    child: DropdownButtonFormField<String>(
                      value: dropdownValue,
                      icon: const Icon(Icons.arrow_downward),
                      decoration: const InputDecoration(
                          fillColor: Colors.purple, labelText: "Gender"),
                      elevation: 16,
                      style: const TextStyle(color: Colors.deepPurple),
                      onChanged: (selectedvalue) {
                        setDropdownState(() {
                          dropdownValue = selectedvalue!;
                          initialvalues.update(
                              "Ggender", (val) => dropdownValue);
                        });
                      },
                      items: genderCode
                          .map(
                            (values) => DropdownMenuItem(
                              value: "${values['item']}",
                              child: Text(
                                "${values['longdesc']}",
                                style: TextStyle(
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                              ),
                            ),
                          )
                          .toList(),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              children: [
                Flexible(
                  child: TextFormField(
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    initialValue: widget.clientRecord["Salutation"],
                    onChanged: (value) {
                      widget.clientRecord.update("Salutation", (val) => value);
                    },
                    decoration: InputDecoration(
                        border: const OutlineInputBorder(),
                        label: Text(
                          "Salutation",
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        )),
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                Flexible(
                  child: TextFormField(
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    initialValue: widget.clientRecord["Language"],
                    onChanged: (value) {
                      widget.clientRecord.update("Language", (val) => value);
                    },
                    decoration: InputDecoration(
                        border: const OutlineInputBorder(),
                        label: Text(
                          "Language",
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        )),
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              children: [
                Flexible(
                  child: TextFormField(
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    initialValue: widget.clientRecord["ClientEmail"],
                    onChanged: (value) {
                      widget.clientRecord.update("ClientEmail", (val) => value);
                    },
                    decoration: InputDecoration(
                        border: const OutlineInputBorder(),
                        label: Text(
                          "Email",
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        )),
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                Flexible(
                  child: TextFormField(
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    initialValue: widget.clientRecord["ClientMobile"],
                    onChanged: (value) {
                      widget.clientRecord
                          .update("ClientMobile", (val) => value);
                    },
                    decoration: InputDecoration(
                        border: const OutlineInputBorder(),
                        label: Text(
                          "Mobile",
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        )),
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              children: [
                // Flexible(
                //   child: TextFormField(
                //     style: TextStyle(
                //       color: Theme.of(context).colorScheme.primary,
                //     ),
                //     initialValue: widget.clientRecord["ClientType"],
                //     onChanged: (value) {
                //       widget.clientRecord.update("ClientType", (val) => value);
                //     },
                //     decoration: InputDecoration(
                //         border: const OutlineInputBorder(),
                //         label: Text(
                //           "Client Type",
                //           style: TextStyle(
                //             color: Theme.of(context).colorScheme.primary,
                //           ),
                //         )),
                //   ),
                // ),
                // const SizedBox(
                //   width: 10,
                // ),
                Flexible(
                  child: TextFormField(
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    initialValue: widget.clientRecord["ClientStatus"],
                    onChanged: (value) {
                      widget.clientRecord
                          .update("ClientStatus", (val) => value);
                    },
                    decoration: InputDecoration(
                        border: const OutlineInputBorder(),
                        label: Text(
                          "Status",
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        )),
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),

                Flexible(
                  child: TextFormField(
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    controller: clientDob,
                    onTap: () async {
                      DateTime? pickeddate = await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: DateTime(1900),
                          lastDate: DateTime.now());
                      if (pickeddate != null) {
                        setState(() {
                          clientDob.text =
                              DateFormat('dd/MM/yyyy').format(pickeddate);
                          widget.clientRecord.update(
                              "ClientDob",
                              (val) =>
                                  DateFormat('yyyyMMdd').format(pickeddate));
                        });
                      }
                    },
                    decoration: InputDecoration(
                        border: const OutlineInputBorder(),
                        label: Text(
                          "Client DOB",
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        )),
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Icon(
              Icons.swipe,
              color: Theme.of(context).colorScheme.primary,
            ),
            Row(
              children: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    foregroundColor: Theme.of(context).colorScheme.onSecondary,
                  ),
                  onPressed: () {
                    resetInitialValues();
                    Navigator.pop(context);
                  },
                  child: const Text(
                    "Close",
                  ),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    foregroundColor: Theme.of(context).colorScheme.onSecondary,
                  ),
                  onPressed: () async {
                    await ClientService.editClient(widget.authToken,
                        widget.companyId, widget.clientRecord);
                    final addressResp = await ClientService.getAllClients(
                      widget.loginResponse['authToken'],
                      searchString.text,
                      searchCriteria,
                      pageNo.text,
                      pageSize,
                    );
                    setState(() {
                      Navigator.pop(context, addressResp["All Clients"]);
                      resetInitialValues();
                    });
                  },
                  child: const Text(
                    "Update",
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
